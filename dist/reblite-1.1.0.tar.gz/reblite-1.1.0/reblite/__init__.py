__title__ = 'FrickDB'
__author__ = 'Harsh Vardhan'
__license__ = 'MIT'
__copyright__ = 'Copyright 2020 Harsh Vardhan'
__version__ = '0.0.1'

from .__main__ import *